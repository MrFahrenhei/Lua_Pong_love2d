Full source code and assets from the tutorial series. - Youtube link: https://www.youtube.com/playlist?list=PL1A1gsSe2tMxngwl-CU1MCX7kmbLf4P5O
Note: The code and assets have different licences

Code: WTFPL (Do whatever you want, no restrictions)
Art: BY-NC-ND (https://creativecommons.org/licenses/by-nc-nd/4.0/) More restricted.
Font: https://www.dafont.com/5x5.font
