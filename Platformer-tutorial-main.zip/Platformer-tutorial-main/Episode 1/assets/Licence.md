BY-NC-ND (https://creativecommons.org/licenses/by-nc-nd/4.0/) 
