Full source code and assets from the tutorial series. 
Note: The code and assets have different licences

Code: WTFPL (Do whatever you want, no restrictions)

Art:  Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (BY-NC-ND) (https://creativecommons.org/licenses/by-nc-nd/4.0/)
